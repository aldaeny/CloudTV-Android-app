# CloudTV – إصلاح بناء APK (ملاحظات المشروع)

## المشاكل التي تم إصلاحها
1. `.github/workflows/build-apk.yml` كان يحتوي على نص عربي (رد نُسخ داخل الملف) بدل YAML، فلم يكن GitHub Actions يقرأه.
   - تم استبداله بـ workflow صالح (تم التحقق من صحة YAML).
2. ملف `github/workflows/build-android.yml` (فارغ، وخارج `.github`) تم حذفه لأن GitHub يتجاهله.
3. خطوات الـ workflow كانت تعدّل `build.gradle` بـ sed هش؛ الآن تُستخدم `scripts/patch-android.mjs` الموجود أصلاً في المشروع
   (cleartext، صلاحية INTERNET، دعم Android TV/Leanback، الإصدار 1.5 / versionCode 15).
4. أضيف فحص صريح لوجود `dist/index.html` بعد بناء الويب، مع رسالة خطأ واضحة.

## تشغيل البناء
- من GitHub → Actions → "Build CloudTV 1.5 APK" → Run workflow (أو تلقائياً عند push إلى main).
- الناتج: artifact باسم `CloudTV-1.5-APK` يحوي `app-debug.apk`.

## ملاحظات
- التوقيع للإصدار النهائي (release) غير مضاف؛ الـ workflow يبني نسخة debug فقط.
- ملف `artifacts/api-server` منفصل عن تطبيق الأندرويد؛ إذا كان التطبيق يعتمد عليه في الإنتاج، يلزم نشره وربط عنوانه.
